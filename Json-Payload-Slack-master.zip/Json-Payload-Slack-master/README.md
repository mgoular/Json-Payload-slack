# Json-Payload-Slack
This is an example of Json Payload to Slack 
